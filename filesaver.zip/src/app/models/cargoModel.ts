export interface Cargo {
  id_cargo?: any
  cargo_nome: String
  cargo_atribuicao: String
}
