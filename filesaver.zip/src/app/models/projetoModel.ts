export interface Projeto {
  id_projeto?: any
  proj_nome: String
  proj_filial: String
}
