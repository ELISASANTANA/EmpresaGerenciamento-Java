export interface Funcionario {
  id_funcionario?: any
  func_nome: String
  func_cidade: String
  id_cargo?: any
  func_foto: String
}
