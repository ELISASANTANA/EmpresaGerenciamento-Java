export interface Salario {
  codigo?: any
  salario_descricao: String
  data_receber_salario: any
  salario_valor: any
  salario_status: String
}
